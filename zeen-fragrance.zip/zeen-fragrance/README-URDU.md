# Zeen's Fragrance — Website (Vercel par chalane ka tareeqa)

Is mein: customer shop, admin panel (`/admin`), stock, orders, in-store sale, discounts aur coupons.

## Deploy karne ke 5 steps

1. **GitHub par upload karein**
   - github.com par naya repository banayein (e.g. `zeens-fragrance`).
   - Is zip ke andar ke sab files/folders (`api`, `lib`, `public`, `package.json`, `vercel.json`) upload karein.

2. **Vercel par import karein**
   - vercel.com par login karein > **Add New > Project** > apna GitHub repo select karein > **Deploy**.
   - Koi setting change nahi karni (Framework: Other).

3. **Database connect karein (zaroori)**
   - Vercel project > **Storage** tab > **Create Database** > **Upstash (Redis)** select karein > Free plan > Create.
   - Jab poochay *Connect to project*, apna project select karein. Environment variables khud add ho jayenge.

4. **Admin password set karein (zaroori)**
   - Project > **Settings > Environment Variables** > naya variable:
     - Name: `ADMIN_PASSWORD`
     - Value: apna mazboot password
   - (Optional) `AUTH_SECRET` = koi bhi lambi random text.

5. **Redeploy**
   - **Deployments** tab > latest deployment > ⋯ > **Redeploy**.
   - Ab `aap-ka-link.vercel.app` par shop chalegi aur `aap-ka-link.vercel.app/admin` par admin login.

## Pehli dafa istemal

- `/admin` par login karein.
- **Products** mein 3 sample perfumes honge (Royal Oud, Velvet Rose, Aqua Breeze). Inhe **Edit** ya **Delete** kar ke apne asli perfumes add karein.
- **Settings** mein WhatsApp number (e.g. `923001234567`), phone, address aur delivery charges likhein.

## Admin panel kya karta hai

| Tab | Kaam |
|---|---|
| Dashboard | Aaj/mahine ki sale, pending orders, kam stock, best sellers |
| Sell (In-Store) | Dukaan par sale: perfume chunein, bill banayein, stock khud kam hota hai |
| Products | Naya perfume: photos (4 tak), notes (Top/Heart/Base), description, sizes (50ml/30ml), price, discount %, stock |
| Orders | Online orders dekhein, status badlein (pending > shipped > delivered). Cancel karne par stock wapas |
| Offers | Poori store ki sale (e.g. Eid Sale 20%) aur coupon codes |
| Settings | Shop ka naam, banner, WhatsApp, delivery charges, free delivery limit |

## Customer ko kya dikhta hai

Photo, naam, notes, size ke hisaab se price, purani price kati hui + % OFF, "Only 3 left" / "Out of stock", cart, coupon, Cash on Delivery checkout, aur order ke baad WhatsApp par confirm karne ka button.

## Zaroori batein

- **Sirf Upstash free plan** kafi hai chhoti dukaan ke liye. Photos automatically chhoti (compress) ho kar save hoti hain.
- Do log bilkul ek hi second mein aakhri piece order karein to bohat kam chance hai ke stock ek se zyada order le le. Chhoti dukaan ke liye yeh theek hai.
- Apna `ADMIN_PASSWORD` kisi ko na batayein. Badalna ho to Vercel mein change kar ke Redeploy karein.
- Apna domain (e.g. zeensfragrance.com) lagana ho to Vercel > Settings > Domains.

## Computer par test karna (optional)

```
ADMIN_PASSWORD=test123 node dev-server.js
```
Phir `http://localhost:3000` aur `http://localhost:3000/admin`.
